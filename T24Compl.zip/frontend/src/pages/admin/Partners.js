import React from 'react';

const Partners = () => {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Franchise Partners</h1>
      <p>This is a placeholder for the Partners dashboard page.</p>
    </div>
  );
};

export default Partners;
